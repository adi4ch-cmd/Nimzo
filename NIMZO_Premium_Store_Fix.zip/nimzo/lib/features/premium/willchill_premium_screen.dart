import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers/supabase_provider.dart';
import 'willchill_membership_showcase.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svga/flutter_svga.dart';
import 'package:flutter_vap_player/flutter_vap_player.dart';

/// Membership destination; source artwork is composed in the tier layout.
class WillChillPremiumScreen extends ConsumerStatefulWidget {
  const WillChillPremiumScreen({super.key, this.initialGroup = 'svip'});
  final String initialGroup;

  @override
  ConsumerState<WillChillPremiumScreen> createState() =>
      _WillChillPremiumScreenState();
}

class _PremiumAsset {
  _PremiumAsset(Map<String, dynamic> json)
      : group = json['group'] as String,
        name = json['name'] as String,
        asset = json['asset'] as String,
        mediaType = json['type'] as String,
        tier = json['tier'] as int?;
  final String group, name, asset, mediaType;
  final int? tier;
  bool get isImage => mediaType == 'image';
  bool get canPlay => mediaType == 'vap' || mediaType == 'svga';
  String get displayName => group == 'entrances' &&
          name.startsWith('voiceroom_crown_orb_')
      ? 'SVIP ${RegExp(r'\d+').firstMatch(name)?.group(0) ?? ''} room entrance'
      : name
          .replaceAll(RegExp(r'\.(png|webp|jpg|svga|mp4)$'), '')
          .replaceAll('_', ' ');
}

final _membershipProvider =
    FutureProvider.autoDispose<Map<String, dynamic>?>((ref) async {
  final session = ref.watch(sessionSupabaseProvider);
  if (session.userId == null) return null;
  return session.client
      .from('profiles')
      .select('svip_level,vip_level,vip_expires_at,svip_cycle_cents')
      .eq('id', session.userId!)
      .maybeSingle()
      .timeout(const Duration(seconds: 6));
});

final _vipOffersProvider =
    FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  final session = ref.watch(sessionSupabaseProvider);
  if (session.userId == null) return [];
  final rows = await session.client
      .from('normal_vip_catalog')
      .select('tier,coin_price,duration_days')
      .order('tier');
  return rows.map((row) => Map<String, dynamic>.from(row)).toList();
});

final _svipThresholdsProvider =
    FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  final session = ref.watch(sessionSupabaseProvider);
  if (session.userId == null) return [];
  final rows = await session.client
      .from('svip_thresholds')
      .select('level,usd_cents')
      .order('level');
  return rows.map((row) => Map<String, dynamic>.from(row)).toList();
});

class _WillChillPremiumScreenState
    extends ConsumerState<WillChillPremiumScreen> {
  List<_PremiumAsset>? _assets;
  Object? _error;
  late final String _group = widget.initialGroup == 'vip' ? 'vip' : 'svip';
  int _tier = 1;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  Future<void> _load() async {
    try {
      final raw = await rootBundle.loadString(
        'assets/willchill_premium/catalog.json',
      );
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      final records = decoded['records'] as List<dynamic>;
      if (!mounted) return;
      setState(() {
        _assets = records
            .map((item) => _PremiumAsset(item as Map<String, dynamic>))
            .toList(growable: false);
        _error = null;
      });
    } catch (error) {
      if (mounted) setState(() => _error = error);
    }
  }

  Widget _svipOverview(int owned, double? progress) {
    final possible = _assets
        ?.where((item) =>
            item.group == 'entrances' &&
            item.name == 'voiceroom_crown_orb_$_tier.mp4')
        .toList();
    final crown = possible == null || possible.isEmpty ? null : possible.first;
    return WillChillMembershipShowcase(
      kind: 'svip',
      growthProgress: progress,
      tier: _tier,
      ownedLevel: owned,
      onTierChanged: (tier) => setState(() => _tier = tier),
      onPreviewEntrance: crown == null
          ? null
          : () => showModalBottomSheet<void>(
              context: context,
              isScrollControlled: true,
              builder: (_) => FractionallySizedBox(
                  heightFactor: .85,
                  child: _PremiumAssetPreview(asset: crown))),
    );
  }

  Widget _vipOverview(int owned) => WillChillMembershipShowcase(
        kind: 'vip',
        tier: _tier > 7 ? 7 : _tier,
        ownedLevel: owned,
        onTierChanged: (tier) => setState(() => _tier = tier),
      );

  @override
  Widget build(BuildContext context) {
    final membership = ref.watch(_membershipProvider);
    final profile = membership.valueOrNull;
    final svip = (profile?['svip_level'] as num?)?.toInt() ?? 0;
    final vip = (profile?['vip_level'] as num?)?.toInt() ?? 0;
    final expiry = DateTime.tryParse('${profile?['vip_expires_at'] ?? ''}');
    final activeVip =
        expiry != null && expiry.isAfter(DateTime.now()) ? vip : 0;
    final status = membership.isLoading
        ? 'Checking membership…'
        : membership.hasError
            ? 'Membership unavailable · tap to retry'
            : profile == null
                ? 'Sign in to view your membership'
                : 'Your account · SVIP $svip · ${activeVip > 0 ? 'VIP $activeVip' : 'VIP inactive'}';
    final offers = ref.watch(_vipOffersProvider).valueOrNull ?? const [];
    final thresholds =
        ref.watch(_svipThresholdsProvider).valueOrNull ?? const [];
    final selectedOffers = offers.where((row) => row['tier'] == _tier);
    final offer = selectedOffers.isEmpty ? null : selectedOffers.first;
    final selectedThresholds = thresholds.where((row) => row['level'] == _tier);
    final threshold = selectedThresholds.isEmpty
        ? null
        : (selectedThresholds.first['usd_cents'] as num?)?.toDouble();
    final cents = (profile?['svip_cycle_cents'] as num?)?.toDouble();
    final progress = threshold != null && threshold > 0 && cents != null
        ? (cents / threshold).clamp(0.0, 1.0)
        : null;
    return Scaffold(
      backgroundColor: const Color(0xff090a10),
      appBar: AppBar(
        title: Text(_group == 'svip' ? 'NIMZO SVIP' : 'NIMZO VIP'),
        centerTitle: true,
        backgroundColor: const Color(0xff100e12),
        foregroundColor: const Color(0xffead8a1),
        actions: [
          IconButton(
            tooltip: 'Membership information',
            icon: const Icon(Icons.help_outline),
            onPressed: () => showModalBottomSheet<void>(
                context: context,
                backgroundColor: const Color(0xff17131c),
                showDragHandle: true,
                builder: (_) => SafeArea(
                    child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(
                            '$status\n\nPreview each tier’s appearance. Membership purchases are currently unavailable.',
                            style: const TextStyle(
                                color: Color(0xffead8a1), height: 1.5))))),
          )
        ],
      ),
      bottomNavigationBar: SafeArea(
          top: false,
          child: Container(
            key: const ValueKey('membership-fixed-status'),
            constraints: const BoxConstraints(minHeight: 72),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xff100e12),
              border: const Border(top: BorderSide(color: Color(0xff806943))),
              image: _group == 'svip'
                  ? DecorationImage(
                      image: AssetImage(
                          'assets/willchill_premium/svip/svip${_tier}_expiration_container.webp'),
                      fit: BoxFit.fill)
                  : null,
            ),
            child: _group == 'svip'
                ? Row(children: [
                    const Icon(Icons.workspace_premium_outlined,
                        color: Color(0xffead8a1)),
                    const SizedBox(width: 12),
                    Expanded(
                        child: Text(
                            membership.isLoading ||
                                    membership.hasError ||
                                    profile == null
                                ? status
                                : svip > 0
                                    ? 'SVIP $svip active'
                                    : 'SVIP Not Unlocked Yet',
                            style: const TextStyle(
                                color: Color(0xffead8a1),
                                fontWeight: FontWeight.w700))),
                  ])
                : Row(children: [
                    Expanded(
                        child: Text(
                            offer == null
                                ? 'Price unavailable'
                                : '${offer['coin_price']} coins / ${offer['duration_days']} days',
                            style: const TextStyle(
                                color: Colors.white, fontSize: 12))),
                    const SizedBox(width: 12),
                    Tooltip(
                        message: 'VIP purchases are currently unavailable',
                        child: FilledButton(
                          onPressed: null,
                          style: FilledButton.styleFrom(
                              disabledBackgroundColor: const Color(0xff988352),
                              disabledForegroundColor: const Color(0xff292018)),
                          child: const Text('Unavailable'),
                        )),
                  ]),
          )),
      body: SafeArea(
          top: false,
          child: _error != null
              ? Center(
                  child: TextButton(
                      onPressed: _load,
                      child: const Text('Unable to load membership · Retry')))
              : _assets == null
                  ? const Center(child: CircularProgressIndicator())
                  : RefreshIndicator(
                      onRefresh: () async {
                        ref.invalidate(_membershipProvider);
                        ref.invalidate(_vipOffersProvider);
                        ref.invalidate(_svipThresholdsProvider);
                        await ref.read(_membershipProvider.future);
                      },
                      child: ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: EdgeInsets.zero,
                        children: [
                          if (membership.hasError)
                            TextButton(
                                key: const ValueKey(
                                    'willchill-membership-status'),
                                onPressed: () =>
                                    ref.invalidate(_membershipProvider),
                                child: Text(status)),
                          if (_group == 'svip') _svipOverview(svip, progress),
                          if (_group == 'vip') _vipOverview(activeVip),
                        ],
                      ),
                    )),
    );
  }
}

class _PremiumAssetPreview extends StatefulWidget {
  const _PremiumAssetPreview({required this.asset});
  final _PremiumAsset asset;
  @override
  State<_PremiumAssetPreview> createState() => _PremiumAssetPreviewState();
}

class _PremiumAssetPreviewState extends State<_PremiumAssetPreview> {
  VapPlayerController? _vap;
  StreamSubscription<VapEvent>? _events;
  bool _initialized = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.asset.mediaType == 'vap') unawaited(_startVap());
  }

  Future<void> _startVap() async {
    try {
      final controller = VapPlayerController.asset(
        widget.asset.asset,
        options: const VapPlayerOptions(
          viewType: VapViewType.textureView,
          scaleType: VapScaleType.fitCenter,
          repeatCount: 0,
          mute: false,
        ),
      );
      _vap = controller;
      _events = controller.events.listen((event) {
        if (event is VapErrorEvent && mounted) {
          setState(() => _error = 'Native VAP playback failed');
        }
      }, onError: (Object _) {
        if (mounted) setState(() => _error = 'VAP event stream failed');
      });
      await controller.initialize();
      if (!mounted) return;
      setState(() => _initialized = true);
      await controller.play();
    } catch (_) {
      if (mounted)
        setState(() => _error = 'Unable to initialize native player');
    }
  }

  @override
  void dispose() {
    unawaited(_events?.cancel());
    final controller = _vap;
    if (controller != null) unawaited(controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xff111a17),
        appBar: AppBar(
          title: Text(widget.asset.displayName,
              maxLines: 1, overflow: TextOverflow.ellipsis),
          backgroundColor: const Color(0xff192e26),
          foregroundColor: Colors.white,
        ),
        body: SafeArea(
          child: Stack(fit: StackFit.expand, children: [
            if (_error != null)
              Center(
                  child: Text(_error!,
                      style: const TextStyle(color: Colors.white)))
            else if (widget.asset.isImage)
              InteractiveViewer(
                  child: Center(
                      child:
                          Image.asset(widget.asset.asset, fit: BoxFit.contain)))
            else if (widget.asset.mediaType == 'svga')
              SVGAEasyPlayer(
                  assetsName: widget.asset.asset, fit: BoxFit.contain)
            else if (widget.asset.mediaType == 'vap' &&
                _initialized &&
                _vap != null)
              VapPlayer(_vap!)
            else if (widget.asset.mediaType == 'vap')
              const Center(child: CircularProgressIndicator())
            else
              const Center(
                  child: Text('Preview not available for this format',
                      style: TextStyle(color: Colors.white))),
            Positioned(
              bottom: 20,
              left: 14,
              right: 14,
              child: Text('Room entrance preview',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70, fontSize: 11)),
            ),
          ]),
        ),
      );
}
