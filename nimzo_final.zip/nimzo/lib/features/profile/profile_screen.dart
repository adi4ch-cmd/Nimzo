import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/providers/supabase_provider.dart';
import '../../core/utils/helpers.dart';
import '../../core/widgets/error_view.dart';
import '../../core/widgets/loading_view.dart';
import '../../core/widgets/nimzo_avatar.dart';
import '../../core/widgets/nimzo_badge.dart';
import '../social/social_repositories.dart';
import 'profile_repository.dart';

/// Same screen for own and other users. userId == null means "me".
class ProfileScreen extends ConsumerWidget {
  final String? userId;
  const ProfileScreen({super.key, this.userId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final me = ref.watch(currentUserIdProvider);
    final id = userId ?? me;
    if (id == null) return const LoadingView();
    final isMe = id == me;
    final p = ref.watch(profileProvider(id));
    final stats = ref.watch(profileStatsProvider(id));
    final db = ref.watch(supabaseProvider);
    return Scaffold(
      appBar: AppBar(title: Text(isMe ? 'Profile' : ''), actions: [
        if (isMe) IconButton(icon: const Icon(Icons.account_balance_wallet_outlined), onPressed: () => context.push('/wallet')),
        if (isMe) IconButton(icon: const Icon(Icons.workspace_premium_outlined), onPressed: () => context.push('/vip')),
        if (isMe) IconButton(icon: const Icon(Icons.history), onPressed: () => context.push('/gift-history')),
        if (isMe) IconButton(icon: const Icon(Icons.shield_outlined), onPressed: () => context.push('/admin')),
        if (isMe) IconButton(icon: const Icon(Icons.settings_outlined), onPressed: () => context.push('/profile-setup')),
      ]),
      body: p.when(
        loading: () => const LoadingView(),
        error: (e, _) => ErrorView(message: '$e', onRetry: () => ref.invalidate(profileProvider(id))),
        data: (u) => DefaultTabController(
          length: 4,
          child: NestedScrollView(
            headerSliverBuilder: (_, __) => [
              SliverToBoxAdapter(child: Column(children: [
                const SizedBox(height: 8),
                NimzoAvatar(radius: 40, url: storageUrl(db, 'avatars', u.avatarPath)),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(u.displayName ?? 'User', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(width: 6), NimzoBadge('Lv ${u.level}'),
                  if (u.vipLevel > 0) ...[const SizedBox(width: 4), NimzoBadge('VIP${u.vipLevel}', gold: true)],
                  if (u.svipLevel > 0) ...[const SizedBox(width: 4), NimzoBadge('SVIP${u.svipLevel}', gold: true)],
                ]),
                Text('Nimzo ID ${u.nimzoId}', style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 12),
                stats.maybeWhen(
                  data: (s) => Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                    for (final k in ['followers', 'following', 'friends', 'visitors', 'moments'])
                      Column(children: [Text('${s[k] ?? 0}', style: Theme.of(context).textTheme.titleMedium), Text(k, style: Theme.of(context).textTheme.bodySmall)])
                  ]),
                  orElse: () => const SizedBox(height: 40),
                ),
                if (!isMe) _Actions(targetId: id),
                const TabBar(tabs: [Tab(text: 'About'), Tab(text: 'Moments'), Tab(text: 'Gifts'), Tab(text: 'Achievements')]),
              ])),
            ],
            body: TabBarView(children: [
              Padding(padding: const EdgeInsets.all(16), child: Text(u.bio ?? 'No bio yet.')),
              const Center(child: Text('No moments yet')),
              const Center(child: Text('No gifts yet')),
              const Center(child: Text('No achievements yet')),
            ]),
          ),
        ),
      ),
    );
  }
}

class _Actions extends ConsumerWidget {
  final String targetId;
  const _Actions({required this.targetId});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final follow = ref.watch(isFollowingProvider(targetId)).valueOrNull ?? false;
    final fs = ref.watch(friendStateProvider(targetId)).valueOrNull ?? FriendState.none;
    final fr = ref.read(friendRepositoryProvider);
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Wrap(spacing: 8, children: [
        FilledButton(
          onPressed: () async {
            final r = ref.read(followRepositoryProvider);
            follow ? await r.unfollow(targetId) : await r.follow(targetId);
            ref.invalidate(isFollowingProvider(targetId));
          },
          child: Text(follow ? 'Following' : 'Follow'),
        ),
        OutlinedButton(onPressed: () => context.push('/chat/$targetId'), child: const Text('Message')),
        OutlinedButton(
          onPressed: switch (fs) {
            FriendState.none => () async { await fr.request(targetId); ref.invalidate(friendStateProvider(targetId)); },
            FriendState.received => () async { await fr.accept(targetId); ref.invalidate(friendStateProvider(targetId)); },
            _ => null,
          },
          child: Text(switch (fs) {
            FriendState.none => 'Add Friend',
            FriendState.sent => 'Request Sent',
            FriendState.received => 'Accept',
            FriendState.friends => 'Friends',
          }),
        ),
      ]),
    );
  }
}
