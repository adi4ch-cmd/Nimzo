import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show FileOptions;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:io';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/providers/supabase_provider.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/nimzo_button.dart';
import '../../core/widgets/nimzo_text_field.dart';
import 'profile_repository.dart';

/// Create username + basic profile. Avatar/cover upload goes to Supabase Storage
/// (avatars/, covers/) then the path is saved with update().
class ProfileSetupScreen extends ConsumerStatefulWidget {
  const ProfileSetupScreen({super.key});
  @override
  ConsumerState<ProfileSetupScreen> createState() => _S();
}

class _S extends ConsumerState<ProfileSetupScreen> {
  final _f = GlobalKey<FormState>();
  final _u = TextEditingController(), _n = TextEditingController(), _b = TextEditingController();
  bool busy = false;
  String? _avatarPath;

  Future<void> _pickAvatar() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1024, imageQuality: 85);
    if (x == null) return;
    final db = ref.read(supabaseProvider);
    final uid = db.auth.currentUser!.id;
    final path = '$uid/avatar.jpg';  // own folder only, enforced by storage policy
    await db.storage.from('avatars').upload(path, File(x.path), fileOptions: const FileOptions(upsert: true));
    setState(() => _avatarPath = path);
  }
  @override
  void dispose() { _u.dispose(); _n.dispose(); _b.dispose(); super.dispose(); }

  Future<void> _save() async {
    if (!_f.currentState!.validate()) return;
    setState(() => busy = true);
    final repo = ref.read(profileRepositoryProvider);
    try {
      if (!await repo.usernameAvailable(_u.text)) throw 'Username is taken';
      await repo.update(username: _u.text, displayName: _n.text.trim(), bio: _b.text.trim(), avatarPath: _avatarPath);
      if (mounted) context.go('/home');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Set up your profile')),
        body: SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: Form(key: _f, child: ListView(children: [
          Center(child: GestureDetector(onTap: _pickAvatar, child: CircleAvatar(radius: 40, child: Icon(_avatarPath == null ? Icons.add_a_photo_outlined : Icons.check)))),
          const SizedBox(height: 16),
          NimzoTextField(controller: _u, label: 'Username', validator: Validators.username),
          const SizedBox(height: 12),
          NimzoTextField(controller: _n, label: 'Display name', validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null),
          const SizedBox(height: 12),
          NimzoTextField(controller: _b, label: 'Bio (optional)'),
          const SizedBox(height: 20),
          NimzoButton(label: 'Save', loading: busy, onPressed: _save),
        ])))),
      );
}
