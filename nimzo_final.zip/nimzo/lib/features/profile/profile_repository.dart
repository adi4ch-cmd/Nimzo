import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/errors/error_handler.dart';
import '../../core/providers/supabase_provider.dart';
import 'profile.dart';

class ProfileRepository {
  final SupabaseClient _db;
  ProfileRepository(this._db);

  Future<Profile> get(String id) async {
    try { return Profile.fromJson(await _db.from('profiles').select().eq('id', id).single()); }
    catch (e) { throw mapError(e); }
  }

  /// Only whitelisted columns are writable (column grants in SQL).
  Future<void> update({String? username, String? displayName, String? bio, String? avatarPath, String? coverPath}) async {
    try {
      final m = <String, dynamic>{
        if (username != null) 'username': username,
        if (displayName != null) 'display_name': displayName,
        if (bio != null) 'bio': bio,
        if (avatarPath != null) 'avatar_path': avatarPath,
        if (coverPath != null) 'cover_path': coverPath,
      };
      await _db.from('profiles').update(m).eq('id', _db.auth.currentUser!.id);
    } catch (e) { throw mapError(e); }
  }

  Future<bool> usernameAvailable(String name) async {
    final r = await _db.from('profiles').select('id').eq('username', name).maybeSingle();
    return r == null;
  }

  Future<List<Profile>> search(String q) async {
    try {
      final id = int.tryParse(q);
      final rows = id != null
          ? await _db.from('profiles').select().eq('nimzo_id', id).limit(20)
          : await _db.from('profiles').select().ilike('display_name', '%$q%').limit(20);
      return rows.map(Profile.fromJson).toList();
    } catch (e) { throw mapError(e); }
  }

  Future<Map<String, int>> stats(String id) async {
    final r = await _db.rpc('profile_stats', params: {'p_user': id});
    return Map<String, int>.from((r as Map).map((k, v) => MapEntry(k as String, (v as num).toInt())));
  }
}

final profileRepositoryProvider = Provider((ref) => ProfileRepository(ref.watch(supabaseProvider)));
final profileProvider = FutureProvider.family<Profile, String>((ref, id) => ref.watch(profileRepositoryProvider).get(id));
final profileStatsProvider = FutureProvider.family<Map<String, int>, String>((ref, id) => ref.watch(profileRepositoryProvider).stats(id));
