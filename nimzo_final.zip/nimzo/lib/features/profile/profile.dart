class Profile {
  final String id;
  final int nimzoId;
  final String? username, displayName, bio, avatarPath, coverPath;
  final int level, vipLevel, svipLevel;
  const Profile({required this.id, required this.nimzoId, this.username, this.displayName, this.bio,
      this.avatarPath, this.coverPath, this.level = 1, this.vipLevel = 0, this.svipLevel = 0});
  factory Profile.fromJson(Map<String, dynamic> j) => Profile(
      id: j['id'], nimzoId: j['nimzo_id'], username: j['username'], displayName: j['display_name'],
      bio: j['bio'], avatarPath: j['avatar_path'], coverPath: j['cover_path'],
      level: j['level'] ?? 1, vipLevel: j['vip_level'] ?? 0, svipLevel: j['svip_level'] ?? 0);
}
