NIMZO gift asset bundle, branch feature/profile-reference-redesign.
Extract the ZIP into the GitHub repository ROOT (preserving nimzo/assets/gifts/).
Code commit bb08f0cb99b59c903faf69b4e1c0c0cb1ec4135b already registers these assets and maps gift IDs.
After adding both files to the branch, run flutter pub get, flutter analyze, flutter test, flutter build apk --release in nimzo/.
Do not publish APK until those checks pass. No database or wallet changes are included.
