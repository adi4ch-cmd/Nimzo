-- Nimzo completion data and supporting backend APIs.
-- Apply after 0001_core.sql through 0005_locked_profile_lifetime_moment_gifts.sql.
-- This migration is intentionally safe to run on a live project: catalog inserts are idempotent.

-- ---------- achievement catalog and progress ----------
create table if not exists public.achievements (
  id text primary key,
  title text not null check (char_length(title) between 1 and 80),
  description text not null check (char_length(description) between 1 and 240),
  category text not null check (category in ('social','rooms','gifts','moments','profile')),
  target_count bigint not null check (target_count > 0),
  sort_order int not null default 0,
  active boolean not null default true
);
create table if not exists public.user_achievements (
  user_id uuid not null references public.profiles(id) on delete cascade,
  achievement_id text not null references public.achievements(id) on delete cascade,
  progress_count bigint not null default 0 check (progress_count >= 0),
  unlocked_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, achievement_id)
);
alter table public.achievements enable row level security;
alter table public.user_achievements enable row level security;
do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='achievements' and policyname='achievements_read') then
    create policy achievements_read on public.achievements for select to authenticated using (active);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='user_achievements' and policyname='user_achievements_read') then
    create policy user_achievements_read on public.user_achievements for select to authenticated using (user_id = auth.uid());
  end if;
end $$;
revoke insert, update, delete on public.achievements, public.user_achievements from authenticated, anon;

insert into public.achievements(id,title,description,category,target_count,sort_order) values
 ('profile_complete','Profile complete','Finish your profile details and photo.','profile',1,10),
 ('first_follow','First follow','Follow your first Nimzo member.','social',1,20),
 ('social_star','Social star','Gain 25 followers.','social',25,30),
 ('room_regular','Room regular','Join 10 rooms.','rooms',10,40),
 ('first_moment','First moment','Publish your first Moment.','moments',1,50),
 ('moment_creator','Moment creator','Publish 10 Moments.','moments',10,60),
 ('first_gift','First gift','Send your first gift.','gifts',1,70),
 ('gift_supporter','Gift supporter','Send 100,000 coins in gifts.','gifts',100000,80)
on conflict (id) do update set title=excluded.title, description=excluded.description,
 category=excluded.category, target_count=excluded.target_count, sort_order=excluded.sort_order;

-- Server-owned upsert. This is callable only by trusted backend jobs / service role.
create or replace function public.record_achievement_progress(p_user uuid, p_achievement text, p_progress bigint)
returns void language plpgsql security definer set search_path=public as $$
declare v_target bigint;
begin
  if auth.role() <> 'service_role' then raise exception 'not allowed'; end if;
  if p_progress < 0 then raise exception 'invalid progress'; end if;
  select target_count into v_target from achievements where id=p_achievement and active;
  if v_target is null then raise exception 'unknown achievement'; end if;
  insert into user_achievements(user_id,achievement_id,progress_count,unlocked_at)
  values(p_user,p_achievement,p_progress,case when p_progress >= v_target then now() end)
  on conflict(user_id,achievement_id) do update set
    progress_count=greatest(user_achievements.progress_count, excluded.progress_count),
    unlocked_at=coalesce(user_achievements.unlocked_at, case when excluded.progress_count >= v_target then now() end),
    updated_at=now();
end $$;
revoke all on function public.record_achievement_progress(uuid,text,bigint) from public, authenticated, anon;

-- ---------- read APIs used by profile and social UI ----------
create or replace function public.friend_list(p_user uuid default auth.uid())
returns table(id uuid, nimzo_id bigint, display_name text, avatar_path text, since timestamptz)
language sql stable security definer set search_path=public as $$
  select p.id,p.nimzo_id,p.display_name,p.avatar_path,f.created_at
  from friendships f join profiles p on p.id=case when f.requester_id=p_user then f.addressee_id else f.requester_id end
  where f.status='accepted' and p_user in (f.requester_id,f.addressee_id)
  order by f.created_at desc
$$;

create or replace function public.profile_moments(p_user uuid)
returns table(id uuid, body text, image_path text, created_at timestamptz, like_count bigint, comment_count bigint, lifetime_gift_coins bigint)
language sql stable security invoker set search_path=public as $$
  select m.id,m.body,m.image_path,m.created_at,
    (select count(*) from moment_likes l where l.moment_id=m.id),
    (select count(*) from moment_comments c where c.moment_id=m.id),
    m.lifetime_gift_coins
  from moments m where m.author_id=p_user order by m.created_at desc limit 100
$$;

create or replace function public.profile_gift_history(p_user uuid)
returns table(kind text, coin_delta bigint, diamond_delta bigint, ref jsonb, created_at timestamptz)
language sql stable security invoker set search_path=public as $$
  select kind,coin_delta,diamond_delta,ref,created_at from ledger
  where user_id=p_user and kind in ('gift_sent','gift_received','moment_gift_sent','moment_gift_received','room_reward')
  order by created_at desc limit 100
$$;

create or replace function public.my_achievements()
returns table(id text, title text, description text, category text, target_count bigint, progress_count bigint, unlocked_at timestamptz)
language sql stable security invoker set search_path=public as $$
  select a.id,a.title,a.description,a.category,a.target_count,coalesce(u.progress_count,0),u.unlocked_at
  from achievements a left join user_achievements u on u.achievement_id=a.id and u.user_id=auth.uid()
  where a.active order by a.sort_order,a.id
$$;

revoke all on function public.friend_list(uuid), public.profile_moments(uuid), public.profile_gift_history(uuid), public.my_achievements() from public;
grant execute on function public.friend_list(uuid), public.profile_moments(uuid), public.profile_gift_history(uuid), public.my_achievements() to authenticated;

-- ---------- room music queue metadata ----------
-- This records a room's queue only. Playback/licensing and any streaming provider stay outside the database.
create table if not exists public.room_music_queue (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  requested_by uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 160),
  source_url text check (source_url is null or source_url ~ '^https://'),
  status text not null default 'queued' check (status in ('queued','playing','skipped','removed')),
  created_at timestamptz not null default now()
);
create index if not exists room_music_queue_room_created on public.room_music_queue(room_id,created_at);
alter table public.room_music_queue enable row level security;
do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='room_music_queue' and policyname='room_music_queue_read') then
    create policy room_music_queue_read on public.room_music_queue for select to authenticated using (
      exists(select 1 from room_members m where m.room_id=room_music_queue.room_id and m.user_id=auth.uid())
    );
  end if;
end $$;
revoke insert, update, delete on public.room_music_queue from authenticated, anon;

create or replace function public.queue_room_music(p_room uuid, p_title text, p_source_url text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if not exists(select 1 from room_members where room_id=p_room and user_id=auth.uid()) then raise exception 'join the room first'; end if;
  if char_length(trim(coalesce(p_title,'')))=0 then raise exception 'title required'; end if;
  insert into room_music_queue(room_id,requested_by,title,source_url) values(p_room,auth.uid(),trim(p_title),p_source_url) returning id into v_id;
  return v_id;
end $$;
create or replace function public.moderate_room_music(p_item uuid, p_status text)
returns void language plpgsql security definer set search_path=public as $$
declare v_room uuid;
begin
  select room_id into v_room from room_music_queue where id=p_item for update;
  if v_room is null then raise exception 'queue item not found'; end if;
  if not exists(select 1 from rooms r where r.id=v_room and r.owner_id=auth.uid())
    and not exists(select 1 from room_members m where m.room_id=v_room and m.user_id=auth.uid() and m.role='moderator') then
    raise exception 'not allowed';
  end if;
  if p_status not in ('playing','skipped','removed') then raise exception 'bad status'; end if;
  update room_music_queue set status=p_status where id=p_item;
end $$;
revoke all on function public.queue_room_music(uuid,text,text), public.moderate_room_music(uuid,text) from public;
grant execute on function public.queue_room_music(uuid,text,text), public.moderate_room_music(uuid,text) to authenticated;

-- ---------- storage hygiene ----------
-- Users can delete only their own avatar, cover, or Moment files.
do $$ begin
  if not exists (select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='user_delete_own_content') then
    create policy user_delete_own_content on storage.objects for delete to authenticated
    using (bucket_id in ('avatars','covers','moments') and (storage.foldername(name))[1]=auth.uid()::text);
  end if;
end $$;
