# Nimzo backend: seeding and deployment

Apply `migrations/0001_core.sql` through `migrations/0006_completion_data.sql` in numeric order using the Supabase CLI or SQL Editor. Migration `0006` adds the achievement catalog and the supporting APIs for friends, profile Moments, gift history, achievements, and room music queue metadata.

## Data that is safe to seed automatically

- Achievement catalog: seeded by migration `0006`.
- Gift catalog: add only approved names, asset paths, coin prices, and VIP restrictions. These are commercial values, so they are deliberately not invented in a migration.
- Recharge packages: add only real Google Play / App Store product IDs. Keep packages inactive until store verification is live.
- Banners: add only approved copy and uploaded image paths.
- VIP/SVIP prices/rewards: values must be confirmed by the owner before production activation.

## Required production checks

1. Create the listed Storage buckets and apply their policies.
2. Deploy `verify-purchase` only after its server-side Google/Apple credentials are configured.
3. Run the SQL security and economy checks in `supabase/tests/` against a non-production test user.
4. Confirm the Google/Facebook provider redirect configuration separately; it is not stored in these migrations.
